#include "cachelab.h"
#include <getopt.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>

// Taylor Hansen and Xuecong Fan
// A01476037 and A01972388

int main(int argc, char *argv[])
{
  /////////////////////////////////////////////////////////////////////////////
  // VARIABLES                                                               //
  /////////////////////////////////////////////////////////////////////////////
    
  int M_count = 0;
  int lru_count = 1;
  int placed = 0;
  int lru_line = 0;
  int option;
  int hit_count = 0;
  int hit = 0;
  int evict_count = 0;
  int evict = 0;
  int miss_count = 0;
  int miss = 0;
  int s;
  int S;
  int E;
  int b;
  int verbose = 0;
  char *t;
  FILE *fp;
  char line[30];
  char oprtn = '0';
  char addr0[10];
  long int addr;
  int i;
  int j;
  int k = 0;
  int count = 1;
  long int mask = 2;
  long int index;
  long int tag;
  long int *blocks;
  int *LRU;
    
  /////////////////////////////////////////////////////////////////////////////
  // GET COMMAND LINE ARGUMENTS                                              //
  /////////////////////////////////////////////////////////////////////////////
    
        while((option = getopt(argc, argv, "v:s:E:b:t:")) != -1)
        {
            switch(option)
            {
                case 'v':
                    verbose = 1;
                case 's':
                    s = atoi(optarg);
                    break;
                case 'E':
                    E = atoi(optarg);
                    break;
                case 'b':
                    b = atoi(optarg);
                    break;
                case 't':
                    t = optarg;
                    break;
                default:
                    printf("ERROR\n");
            }
            
        }
    
  /////////////////////////////////////////////////////////////////////////////
  // SETUP MASK AND CACHE DIMENSIONS AND INITIALIZE CACHE AS EMPTY           //
  /////////////////////////////////////////////////////////////////////////////
    
  // mask is (2^s)-1
  for(i = 0; i < s-1; i++)
    {
      mask *= 2;
    }
  i = 0;
  S = (int)mask;
  mask--;
    
  // cache dimensions
  blocks = (long int*)malloc(S*E*sizeof(long int));
  LRU = (int*)malloc(S*E*sizeof(int));
    
  // set all addresses in cache as empty
  for (i = 0; i < S; i++)
    {
    for (j = 0; j < E; j++)
      {
      LRU[i*E+j] = 0;
      }
    }
  i = 0;
  j = 0;
    
  /////////////////////////////////////////////////////////////////////////////
  // GET NEXT LINE, OPERATION, AND ADDRESS                                   //
  /////////////////////////////////////////////////////////////////////////////
    
  fp = fopen(t,"r");
  while(!feof(fp))
    {
      // get next line from input file
      fgets(line,30,fp);
      
      
      for(i = 0; i < 30; i++)
        {
	  // get operation from current line
	  if(count == 1 && line[i] != ' ')
            {
	      oprtn = line[i];
	      count++;
            }

	  // get address from current line
	  else if(count == 2 && line[i] != ' ')
            {
	      if(line[i] == ',')
                {
		  count++;
                }
	      else
                {
		  addr0[k] = line[i];
		  k++;
                }
            }
        }

  /////////////////////////////////////////////////////////////////////////////
  // SIMULATE CACHE BEHAVIOR                                                 //
  /////////////////////////////////////////////////////////////////////////////

      // ignore 'I' operations
      if(oprtn == 'L' || oprtn == 'M' || oprtn == 'S')
        {

	  // change address to long int;
	  addr = strtol(addr0,NULL,16);

	  // get set index and tag from address;
	  index = (addr >> b) & mask;
	  tag = addr >> (b+s); 
            
	  do{
            
            if(oprtn == 'M')
	      {
                M_count++;
	      }
            
            // check all lines at current index to see if tag is already there
            for(i = 0; i < E; i++)
	      {
                if(blocks[index*E + i] == tag && LRU[index*E + i] != 0 &&placed == 0)
		  {
		    hit_count++;
		    hit = 1;
		    LRU[index*E+i] = lru_count;
		    lru_count++;
		    placed = 1;
		  }
	      }
            
	    // if tag is not in any lines, check for an empty line
            if(placed == 0)
	      {
                for(i = 0; i < E; i++)
		  {
                    if(LRU[index*E+i] == 0 && placed == 0)
		      {
                        miss_count++;
                        miss = 1;
                        LRU[index*E+i] = lru_count;
                        lru_count++;
                        blocks[index*E+i] = tag;
                        placed = 1;
		      }
		  }
	      }
            
	    // if tag is not found and no empty lines are found, place current tag in LRU line
            if(placed == 0)
	      {
                miss_count++;
                miss = 1;
		
		// find least recently used line
                lru_line = LRU[index*E];
                for(i = 0; i < E; i++)
		  {
                    for(j = 0; j < E; j++)
		      {
                        if(LRU[index*E+i] < LRU[index*E+j] && LRU[index*E+i] < lru_line)
			  {
                            lru_line = LRU[index*E+i];
			  }
		      }
		  }
                
		// evict least recently used line            
                for(i = 0; i < E; i++)
		  {
                    if(LRU[index*E+i] == lru_line && placed == 0)
		      {
			blocks[index*E+i] = tag;
			LRU[index*E+i] = lru_count;
			lru_count++;
			evict_count++;
			evict = 1;
			placed = 1;
		      }
		  }
	      }
            
	    // reset placed variable
            placed = 0;

	  //if operation is 'M' repeat one more time
	  }while(M_count == 1);
          
  /////////////////////////////////////////////////////////////////////////////
  // IF VERBOSE SET PRINT EACH ACTION                                        //
  /////////////////////////////////////////////////////////////////////////////  
            
	  if(verbose == 1)
            {
	      printf("%s ",line);
	      if(miss == 1)
                {
		  printf("miss ");
                }
                
	      if(evict == 1)
                {
		  printf("eviction ");
                }
                
	      if(hit == 1)
                {
		  printf("hit ");
		  if(oprtn == 'M' && miss == 0)
                    {
		      printf("hit ");
                    }
                }
	      printf("\n\n");
            }
        }

  /////////////////////////////////////////////////////////////////////////////
  // RESET VARIABLES FOR NEW LINE                                            //
  /////////////////////////////////////////////////////////////////////////////  

      miss = 0;
      hit = 0;
      evict = 0;
      M_count = 0;
      i = 0;
      count = 1;
      k = 0;
      for(i = 0; i < 10; i++)
        {
	  addr0[i] = 0;
        }

      for(i = 0; i < 30; i++)
        {
	  line[i] = 0;
        }
    }

  /////////////////////////////////////////////////////////////////////////////
  // CLOSE FILE AND PRINT TOTAL RESULTS                                      //
  /////////////////////////////////////////////////////////////////////////////  
    
  fclose(fp);

  free(blocks);
  free(LRU);

  printSummary(hit_count, miss_count, evict_count);

  return 0;
}
